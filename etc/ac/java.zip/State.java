/**
 * <p>
 * The State class holds information on state name and state 
 * code. The Stste class can only be instatiated by providing
 * both state code and state name as constructor arguments.
 * 
 * <p>
 * The class is designed for US states, it is not intended as 
 * being able to hold states from other areas of the world. 
 * 
 * <p>
 * A State object is basically a code, associating a name and a value, 
 * and codes are typically handled by a core class of the application
 * architecture. That is, you would typically have a single method that
 * manages retrival of all codes (not only this one), and the approach 
 * shown here is only used for learning purposes.
 *  
 * <p>
 * (C) 2000 Andersen Consulting
 * All Rights Reserved
 *<p>
 */

public class State  {
		
	private String stateName;
	private String stateCode;
			
	/**
	 * Allocates a State object with state code and state name
	 * provided as arguments.
	 */		
	public State(String code, String name) 
	{
		stateName = name;
		stateCode = code;
	}
		
	/**
	 * @return the state name
	 */							
	public String getStateName() 
	{
		return stateName;
	}
		
	/**
	 * @return the state code
	 */							
	public String getStateCode() 
	{
		return stateCode;	
	}
		
	/**
	 * This method overrides the toString method of the
	 * super Object, in order to provide a meaningfull 
	 * string representation of State objects. The string
	 * representation consists here of the state name.
	 * 
	 * @return the object string representation.
	 */							
	public String toString() 
	{
		return stateName;
	}		
	
}
