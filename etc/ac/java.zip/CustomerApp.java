import com.ms.wfc.app.*;

/**
 * <p>
 * The customer application class is used as the entry point for
 * the application, which the sole purpose of starting the
 * application.
 * 
 * <p>
 * (C) 2000 Andersen Consulting
 * All Rights Reserved
 *<p>
 */


public class CustomerApp {
		
    /**
    * The main entry point for the application.
    *
    * @param args Array of parameters passed to the application
    * via the command line.
    */
    public static void main(String args[])
    {        
		new CustomerDetailCtrl();
		Application.run();		
    }		
	
}
