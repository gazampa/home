import com.ms.wfc.data.*;
import java.util.Vector;

/**
 * <p>
 * The CustomerTypes class is designed to hold a list of 
 * CustomerType objects (which represent all customer type defined
 * in the CustomerTypes database). 
 * 
 * <p>
 * A CustomerType object is basically a code, associating a name and a 
 * value, and codes are typically handled by a core class of the 
 * application architecture. That is, you would typically have a single 
 * method that manages retrival of all codes (not only this one), and 
 * the approach shown here is only used for learning purposes.
 * 
 * <p>
 * (C) 2000 Andersen Consulting
 * All Rights Reserved
 *<p>
 */

public class CustomerTypes 
{
	
	private final static String CONN_CMD = "DSN=UNITEL;UID=sa";

	/**
	 * Calls the private fetchCustomerTypes method which returns a
	 * Vector containing the CustomerType objects, representing all
	 * valid customer types.
	 * 
	 * The CustomerType objects of this Vector is the inserted into
	 * a customer type array which is returned.
	 * 
	 * @return Customertype[] - Array of all valid customer types
	 */			
	public CustomerType[] getCustomerTypes() 
	{
		Vector customerTypes = fetchCustomerTypes();
		CustomerType[] types = new CustomerType[customerTypes.size()];
		for (int i = 0; i < customerTypes.size(); i++) 
		{
			types[i] = (CustomerType) customerTypes.elementAt(i);
		}
		return types;
	}
		
	
	/**
	 * Conects to the database and retrieves all customer types. Then
	 * iterates through the resulting rows, and for each row a 
	 * CustomerType object is created and added to the Vector, which 
	 * is returned as the method result.
	 * 
	 * @return Vector - all valid customer types
	 */		
	private Vector fetchCustomerTypes() 
	{
		
		Vector customerTypes = new Vector();
		Recordset rs = new Recordset();
		Connection conn = new Connection();
		conn.setConnectionString(CONN_CMD);
				
		try 
		{
			conn.open();
			StringBuffer sql = new StringBuffer();
			sql.append("Select CustomerTypeID, CustomerType ");
			sql.append("FROM CustomerTypes");
			
			rs = conn.execute(sql.toString());
						
			rs.moveFirst();
			CustomerType customerType;
			while (!rs.getEOF()) 
			{
				int id = rs.getField("CustomerTypeID").getInt();
				String name = rs.getField("CustomerType").getString();
				customerType = new CustomerType(id, name);
				customerTypes.addElement(customerType);
				rs.moveNext();
			}
			rs.close();
		}
		
		catch(Exception e) 
		{
			System.out.println("Exception: " + e);
		}
		finally 
		{
			try {conn.close();} catch(Exception e) {}
		}
		return customerTypes;
	}
					
}

