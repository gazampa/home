/**
 * <p>
 * The States class is designed to hold a list of 
 * State objects (which represent all US States). 
 * 
 * All US states is added upon instantiation of the
 * class, that is, through the class constructor.
 *  
 * <p>
 * A State object is basically a code, associating a name and a value, 
 * and codes are typically handled by a core class of the application
 * architecture. That is, you would typically have a single method that
 * manages retrival of all codes (not only this one), and the approach 
 * shown here is only used for learning purposes.
 * 
 * <p>
 * (C) 2000 Andersen Consulting
 * All Rights Reserved
 *<p>
 */

public class States 
{
	private State[] usStates;
	
	/**
	 * Allocates a States object and initializes the 
	 * array containing objects representing all US 
	 * states
	 */			
	public States() 
	{
		buildUSStateList();		
	}	

	/**
	 * @return the state array
	 */							
	public State[] getAllUSStates() 
	{
		return usStates;
	}
		
	/**
	 * Assigns state array to a new array instance, and
	 * adds State objects to this array. Each object
	 * represents a US state.
	 * 
	 */								
	private void buildUSStateList() 
	{
		
		usStates = new State[50];

		usStates[0] = new State("AL", "Alabama");		
		usStates[1] = new State("AK", "Alaska");
		usStates[2] = new State("AZ", "Arizona");
		usStates[3] = new State("AR", "Arkansas");
		usStates[4] = new State("CA", "California");
		usStates[5] = new State("CO", "Colorado");
		usStates[6] = new State("CT", "Connecticut");
		usStates[7] = new State("DE", "Delaware");
		usStates[8] = new State("DC", "Florida");
		usStates[9] = new State("GA", "Georgia");
		usStates[10] = new State("HI", "Hawaii");
		usStates[11] = new State("ID", "Idaho");
		usStates[12] = new State("IL", "Illinois");
		usStates[13] = new State("IN", "Indiana");
		usStates[14] = new State("IA", "Iowa");
		usStates[15] = new State("KS", "Kansas");
		usStates[16] = new State("KY", "Kentucky");
		usStates[17] = new State("LA", "Louisiana");
		usStates[18] = new State("ME", "Maine");
		usStates[19] = new State("MD", "Maryland");
		usStates[20] = new State("MA", "Massachusetts");
		usStates[21] = new State("MI", "Michigan");
		usStates[22] = new State("MN", "Minnesota");
		usStates[23] = new State("MS", "Mississippi");
		usStates[24] = new State("MO", "Missouri");
		usStates[25] = new State("MT", "Montana");
		usStates[26] = new State("NE", "Nebraska");
		usStates[27] = new State("NV", "Nevada");
		usStates[28] = new State("NH", "New Hampshire");
		usStates[29] = new State("NJ", "New Jersey");
		usStates[30] = new State("NM", "New Mexico");
		usStates[31] = new State("NY", "New York");
		usStates[32] = new State("NC", "North Carolina");
		usStates[33] = new State("ND", "North Dakota");
		usStates[34] = new State("OH", "Ohio");
		usStates[35] = new State("OK", "Oklahoma");
		usStates[36] = new State("OR", "Oregon");
		usStates[37] = new State("PA", "Pennsylvania");
		usStates[38] = new State("RI", "Rhode Island");
		usStates[39] = new State("SC", "South Carolina");
		usStates[40] = new State("SD", "South Dakota");
		usStates[41] = new State("TN", "Tennessee");
		usStates[42] = new State("TX", "Texas");
		usStates[43] = new State("UT", "Utah");
		usStates[44] = new State("VT", "Vermont");
		usStates[45] = new State("VA", "Virginia");
		usStates[46] = new State("WA", "Washington");
		usStates[47] = new State("WV", "West Virginia");
		usStates[48] = new State("WI", "Wisconsin");
		usStates[49] = new State("WY", "Wyoming");
		
	}		
}
