import com.ms.wfc.data.*;
import com.ms.com.*;

/**
 * <p>
 * The Customer class holds information on a user signed in to the
 * system. The object can exists without the user being signed in, but
 * in this case the object basically only holds the information that
 * the user is not signed in.
 * <p>
 * The customer information includes name, address, customer type and
 * discount rate, user id and password.
 * <p>
 * When the customer is being signed in, all customer information
 * is fetched from the database, and the customer properties are set. 
 * This includes getting the discount rate for the customer, which 
 * should be used as input for all object that need this information.
 * <p>
 * (C) 2000 Andersen Consulting
 * All Rights Reserved
 *<p>
 */
 

public class Customer
{
		
	
	private int id;
	
	private int customerTypeId;	
	private String corporateName = "";
	private String firstName = "";
	private String lastName = "";
	private String middleInitial = "";
	private String emailAddress = "";	
	private String address1 = "";
    private String address2 = "";
	private String city = "";
	private String state = "";
	private String country = "";
	private String zip = "";
	private String phone = "";
	
	private float discountRate;
	
	private String userId = "";
	private String password = "";
	
	private boolean signedIn = false;

	private final static String CONN_CMD = "DSN=UNITEL;UID=sa";	
	
	/**
	 * Allocates a Cutsomer object where UserId and password are
	 * not specified and the signedIn variable set to false indicating
	 * that the customer is not signed in
	 */	
	public Customer() {
	}
	

	/**
	 * Adds a customer. First it is determined whether a user id is
	 * supplied, and return an error if that is not the case.
	 * 
	 * Then examine whether the specified user id already exists, and
	 * report back if that is the case.
	 * 
	 * Lastly, insert to customer data in the datastore.
	 * 
	 * @exception If the user ID is not provided, if the user ID is
	 * already registrated to another user, or if an exception by 
	 * invoking the insert method is thrown.
	 * 
	 */		
	public void addCustomer() throws Exception {
		
		if (getUserId().equals("")) {
			handleError("User ID not provided");
		}
		
		if (rowExists()) {
			handleError("User ID already registered");
		}
		
		insert();		
		
	}
	

	/**
	 * Update customer information. User id can not be updated.
	 * 
	 * First it is determined whether a user id is supplied, and 
	 * return an error if that is not the case. Then the customer 
	 * data in the datastore is updated.
	 * 
	 * @return true if updating the customer data was successfull, false 
	 * otherwise
	 */			
	public void updateCustomer() throws Exception{

		if (getUserId().equals("")) {
			handleError("User ID not provided");
		}
		
		update();
		
	}
	
	
	/**
	 * Signs in the customer based on the user id and password given
	 * as input. If the user is already signed then the first step is
	 * to sign out this customer. 
	 * 
	 * The customer information is fetched based on the user id, and
	 * the password is verified to match this information.
	 * 
	 * @param id - The customer user id
	 * @param passwd - The customer password
	 * 
	 * @return true if the sign in process is successfull, false 
	 * otherwise
	 */	
	public boolean signIn(String id, String passwd) {
		if (isSignedIn()) {
			signOut();
		}
		
		setUserId(id);
		
		// Go fetch the customer
		try {
			fetch();
		}
		catch (Exception e) {
			// discard exception and return false;
			return false;
		}
		if (getPassword().equals(passwd)) {
		  setSignedIn(true);	
		}
		else {
			return false;
		}

		return isSignedIn();
		
	}		

	/**
	 * Signs out the customer. All instance variables are
	 * reset and the signed in state is set to false.
	 * 
	 */		
	public void signOut() {
		
		id = 0;
		customerTypeId = 0;	
		corporateName = "";
		firstName = "";
		lastName = "";
		middleInitial = "";
		emailAddress = "";	
		address1 = "";
		address2 = "";
		city = "";
		state = "";
		country = "";
		zip = "";
		phone = "";
		discountRate = 0;
		userId = "";
		password = "";
		
		
		setSignedIn(false);
		
	}	
	
	/**
	 * Sets the signed in state to that of the input argument
	 * 
	 * @param signedInState the new sign in state
	 */				
	private void setSignedIn(boolean signedInState) {		
		signedIn = signedInState;
	}
	
	/**
	 * Returns the signed in state
	 * 
	 * @return <code>true</code> if the customer is currently
	 * signed in, and <code>false</code> otherwise.
	 */			
	public boolean isSignedIn() {
		return signedIn;
	}
	

		
	/**
	 * @return the customer id
	 */				
	public int getCustomerId() {
		return id;
	}
	
	/**
	 * Sets the customer id
	 * 
	 * @param customerId the customer id
	 */					
	public void setCustomerId(int cId) {
	  id = cId;	
	}

	/**
	 * @return the customer type id:
	 * <ul>
	 * <li>0 = Personal
	 * <li>1 = Employee
	 * <li>2 = Corporate
	 * </ul>
	 */					
	public int getCustomerTypeId() {
		return customerTypeId;
	}

	/**
	 * Sets the customer type id
	 * <ul>
	 * <li>0 = Personal
	 * <li>1 = Employee
	 * <li>2 = Corporate
	 * </ul>
	 * 
	 * @param customerTypeId the customer type id
	 */						
	public void setCustomerTypeId(int id) {
	  customerTypeId = id;	
	}

	/**
	 * @return the corporate name
	 */					
	public String getCorporateName() {
		return corporateName;
	}

	/**
	 * Sets the corporate name
	 * 
	 * @param corporateName the corporate name
	 */						
	public void setCorporateName(String s) {
	  corporateName = s;	
	}

	/**
	 * @return the first name
	 */						
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name
	 * 
	 * @param firstName the first name
	 */							
	public void setFirstName(String s) {
	  firstName = s;	
	}

	/**
	 * @return the last name
	 */						
	public String getLastName() {
		return lastName;
	}
	
	/**
	 * Sets the last name
	 * 
	 * @param lastName the last name
	 */							
	public void setLastName(String s) {
	  lastName = s;	
	}

	/**
	 * @return the middle initial
	 */						
	public String getMiddleInitial() {
		return middleInitial;
	}
	
	/**
	 * Sets the middle initial
	 * 
	 * @param middleInitial the middle initial
	 */							
	public void setMiddleInitial(String s) {
	  middleInitial = s;	
	}

	/**
	 * @return the email address
	 */						
	public String getEmailAddress() {
		return emailAddress;
	}
	
	/**
	 * Sets the email address
	 * 
	 * @param email the email address
	 */							
	public void setEmailAddress(String s) {
	  emailAddress = s;	
	}
	
	/**
	 * @return the first address line
	 */						
	public String getAddress1() {
		return address1;
	}
	
	/**
	 * Sets the first address line
	 * 
	 * @param address1 the first address line
	 */							
	public void setAddress1(String s) {
	  address1 = s;	
	}

	/**
	 * @return the second address line
	 */						
	public String getAddress2() {
		return address2;
	}  

	/**
	 * Sets the second address line
	 * 
	 * @param address2 the second address line
	 */							
	public void setAddress2(String s) {
	  address2 = s;	
	}

	/**
	 * @return the city
	 */						
	public String getCity() {
		return city;
	}  
	
	/**
	 * Sets the city
	 * 
	 * @param city the city
	 */							
	public void setCity(String cty) {
	  city = cty;	
	}
	
	/**
	 * @return the state
	 */						
	public String getState() {
		return state;
	}  

	/**
	 * Sets the US state 
	 * 
	 * @param s the US state
	 */								
	public void setState(String s) {
	  state = s;	
	}

	/**
	 * @return the postal code
	 */						
	public String getZip() {
		return zip;
	}  
	
	/**
	 * Sets the postal code
	 * 
	 * @param zipCode the postal code
	 */								
	public void setZip(String zipCode) {
	  zip = zipCode;	
	}
	
	/**
	 * @return the customer's phone number
	 */						
	public String getPhone() {
		return phone;
	}  
	
	/**
	 * Sets the customer's phone number
	 * 
	 * @param phone the customer's phone number
	 */								
	public void setPhone(String pNum) {
	  phone = pNum;	
	}

	/**
	 * Returns the discount rate of the customer. The discount
	 * rate is based on the customer type
	 * 
	 * @return the customer discount rate
	 * 
	 * @see #getCustomerTypeId
	 */						
	public float getDiscountRate() {
		return discountRate;
	}  
	
	/**
	 * Sets the discount rate
	 * 
	 * @param rate the discount rate
	 */								
	public void setDiscountRate(float r) {
	  discountRate = r;	
	}

	/**
	 * @return the user id
	 */						
	public String getUserId() {
		return userId;
	}
	
	/**
	 * Sets the user id
	 * 
	 * @param id the user id
	 */								
	public void setUserId(String uId) {
	  userId = uId;	
	}

	/**
	 * @return the password
	 */							
	public String getPassword() {
	  return password;	
	}
	
	/**
	 * Sets the password
	 * 
	 * @param passwd the password
	 */								
	public void setPassword(String passwd) {
	  password = passwd;	
	}

	/**
	 * Resets the password to "abcde"
	 * 
	 */								
	public void resetPassword() {
	  password = "abcdef";	
	}
	
	
	/**
	 * Connects to the database and deletes the customer.
	 * 
	 * This method should not be called without having specified
	 * the user id.
	 * 
	 * @return boolean that tells whether the operation was successfull.
	 * 
	 * @see #setUserId
	 */											
	private void drop() throws Exception {

		if (getUserId().equals("")) {
			throw new Exception("User ID not provided.");	
		}

		Recordset  rs   = new Recordset();
		Connection conn  = new Connection();
		


		conn.open("dsn=unitel","sa", "");
			
		StringBuffer sql = new StringBuffer();
		sql.append("DELETE FROM Customers A ");
		sql.append("WHERE A.UserId = '" + getUserId() + "'");
									
		rs = conn.execute(sql.toString());

		conn.close();
		
		signOut();
			
	}	
	
	/**
	 * Connects to the database and inserts the new customer.
	 * 
	 * This method should not be called without having at least specified
	 * the user id.
	 * 
	 * @return boolean that tells whether the operation was successfull.
	 * 
	 * @see #setUserId
	 */										
	private void insert() throws Exception {

		Recordset  rs   = new Recordset();
		Connection conn  = new Connection();
		

		conn.open("dsn=unitel","sa", "");
		
		StringBuffer sql = new StringBuffer();			
		
		sql.append("INSERT INTO Customers ");
		sql.append(" (CustomerTypeID, ");
		sql.append(" CorporateName,	");
		sql.append(" UserID, ");
		sql.append(" Password, ");
		sql.append(" LastName, ");
		sql.append(" FirstName,	");
		sql.append(" MiddleInitial, ");
		sql.append(" EmailAddress, ");
		sql.append(" Address1, ");
		sql.append(" Address2, ");
		sql.append(" City, ");
		sql.append(" State, ");
		sql.append(" ZIP, ");
		sql.append(" Phone) ");
		sql.append(" VALUES ( ");
		sql.append("'" + getCustomerTypeId() + "' ");
		sql.append(",'" + getCorporateName() + "' ");
		sql.append(",'" + getUserId() + "' ");
		sql.append(",'" + getPassword() + "' ");
		sql.append(",'" + getLastName() + "' ");
		sql.append(",'" + getFirstName() + "' ");
		sql.append(",'" + getMiddleInitial() + "' ");					 
		sql.append(",'" + getEmailAddress() + "' ");					 					 
		sql.append(",'" + getAddress1() + "' ");
		sql.append(",'" + getAddress2() + "' ");
		sql.append(",'" + getCity() + "' ");
		sql.append(",'" + getState() + "' ");					 
		sql.append(",'" + getZip() + "' ");
		sql.append(",'" + getPhone() + "')"); 
	
		rs = conn.execute(sql.toString());

		conn.close();
		
		fetch();
		
	}
	

	
	/**
	 * Connects to the database and updates the customer information. 
	 * The user id can not be updated.
	 * 
	 * This method should not be called without having specified
	 * the user id.
	 * 
	 * @return boolean that tells whether the operation was successfull.
	 * 
	 * @see #signIn
	 */									
	private void update() throws Exception {

		Recordset  rs   = new Recordset();
		Connection conn  = new Connection();
		

		
		conn.open("dsn=unitel","sa", "");

		StringBuffer sql = new StringBuffer();			
		
		sql.append("UPDATE Customers ");
		sql.append(" SET ");		
		sql.append(" CustomerTypeID = '" + getCustomerTypeId() + "', ");		
		sql.append(" CorporateName = '" + getCorporateName() + "', ");
		sql.append(" Password = '" + getPassword() + "', ");
		sql.append(" LastName = '" + getLastName() + "', ");
		sql.append(" FirstName = '" + getFirstName() + "', ");
		sql.append(" MiddleInitial = '" + getMiddleInitial() + "', ");
		sql.append(" EmailAddress = '" + getEmailAddress() + "', ");
		sql.append(" Address1 = '" + getAddress1() + "', ");		 
		sql.append(" Address2 = '" + getAddress2() + "', ");
		sql.append(" City = '" + getCity() + "', ");
		sql.append(" State = '" + getState() + "', ");					 
		sql.append(" ZIP = '" + getZip() + "', ");					 		
		sql.append(" Phone = '" + getPhone() + "' ");
		sql.append(" WHERE UserID = '" + getUserId() + "'");

		rs = conn.execute(sql.toString());		

		conn.close();
		
	}
	
	/**
	 * Connects to the database and selects rows that matches the
	 * user id. If a row is found, that would indicate the a 
	 * customer with this user id is already registered in the system.
	 * 
	 * This method should not be called without having specified
	 * the user id.
	 * 
	 * @return boolean that tells if the user id already exists.
	 * 
	 * @see #setUserId
	 */									
	private boolean rowExists() throws Exception {

        boolean    success = false ;
		boolean rowFound = false;
		Recordset  rs   = new Recordset();
		Connection conn  = new Connection();
		

		conn.open("dsn=unitel","sa", "");

		StringBuffer sql = new StringBuffer();			

		sql.append("SELECT UserId FROM Customers A ");
		sql.append(" WHERE A.UserID = '" + getUserId() + "'");
				
		rs = conn.execute(sql.toString());
		if (!rs.getEOF()) rowFound = true;
		
		rs.close();		
				
		return rowFound;

	}
		
	/**
	 * Connects to the database and retrieves the customer information related
	 * to the user id. This method should not be called without having specified
	 * the user id.
	 * 
	 * @return boolean that tells whether the operation was successfull.
	 * 
	 * @see #signIn
	 */								
	private void fetch() throws Exception {
		
		Recordset  rs   = new Recordset();
		Connection conn  = new Connection();

			
		conn.open("dsn=unitel","sa", "");

		StringBuffer sql = new StringBuffer();			

		sql.append("SELECT ");
		sql.append(	" A.CustomerID, ");
		sql.append(	" A.CustomerTypeID, ");
		sql.append(	" A.CorporateName, ");
		sql.append(	" A.UserID, ");
		sql.append(	" A.Password, ");
		sql.append(	" A.LastName, ");
		sql.append(	" A.FirstName, ");
		sql.append(	" A.MiddleInitial, ");
		sql.append(	" A.EmailAddress, ");
		sql.append(	" A.Address1, ");				 
		sql.append(	" A.Address2, ");
		sql.append(	" A.City, ");
		sql.append(	" A.State, ");					 
		sql.append(	" A.ZIP, ");					 
		sql.append(	" A.Phone, ");
		sql.append(	" B.CustomerDiscount ");
		sql.append(	" FROM Customers A, CustomerTypes B");
		sql.append(	" WHERE A.UserID = '" + getUserId() + "'");
		sql.append(	"   AND A.CustomerTypeID = B.CustomerTypeID");
			
		rs = conn.execute(sql.toString());
		
		if (rs.getEOF()) return;
			
		rs.moveFirst();
			
		setCustomerId(rs.getField("CustomerID").getInt());
		setCustomerTypeId(rs.getField("CustomerTypeID").getInt());			
		setCorporateName(rs.getField("CorporateName").getString());			
		setUserId(rs.getField("UserID").getString());			
		setPassword(rs.getField("Password").getString());			
		setFirstName(rs.getField("FirstName").getString());			
		setLastName(rs.getField("LastName").getString());			
		setMiddleInitial(rs.getField("MiddleInitial").getString());
		setEmailAddress(rs.getField("EmailAddress").getString());			
		setAddress1(rs.getField("Address1").getString());
		setAddress2(rs.getField("Address2").getString());
		setCity(rs.getField("City").getString());
		setState(rs.getField("State").getString());
		setZip(rs.getField("ZIP").getString());
		setPhone(rs.getField("Phone").getString());
		setDiscountRate(rs.getField("CustomerDiscount").getInt());
			
						
		rs.close();
			
		conn.close();		
		
	}
	
	/**
	 * Utility function for handling errors
	 * 
	 * @param error the error text
	 */									
	private void handleError(String s) throws Exception {
		
		throw new Exception(s);
	}
		
}
