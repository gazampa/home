/**
 * <p>
 * This class represents the top of the Controller hierarchy. 
 * Controllers are classes that are reponsible for the logic 
 * of the window assiciated with this controller. 
 * 
 * <p>
 * All windows (GUI) should have a controller attached to it.
 * 
 * <p>
 * This class is declared as abstract and can therefore not be
 * instantiated. The class defined four abstract methods, that 
 * all non-abstract descendants is required to implement.
 * 
 * Furthermore mode constants are defined (used by controllers 
 * which associated window is mode-aware)
 * 
 * <p>
 * (C) 2000 Andersen Consulting
 * All Rights Reserved
 *<p>
 */

public abstract class UIController {
	
	public static final int ADD_MODE = 0;
	public static final int UPDATE_MODE = 1;
	public static final int VIEW_MODE = 2;
		
	/**
	 * Enables and disables controls on the window that
	 * is assiciated to the controller.
	 */								
	public abstract void determineFormState();

	/**
	 * Displays the window associated to the controller.
	 */									
	public abstract void showForm();
	
	/**
	 * Responsible for coordinating all initialization of
	 * the window associated with the controller.
	 */									
	public abstract void initForm();

	/**
	 * Populates all controls on the windows assiciated with
	 * the controller before the window is displayed.
	 */									
	public abstract void populateForm();
	

}
