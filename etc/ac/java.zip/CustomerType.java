/**
 * <p>
 * The CustomerType class holds information on a specific customer 
 * type id and the type name belonging to this ID. 
 * 
 * <p>
 * The CustomerType class can only be instatiated by providing
 * both customer type id and customer type name as constructor 
 * arguments.
 * 
 * <p>
 * A CustomerType object is basically a code, associating a name and a 
 * value, and codes are typically handled by a core class of the 
 * application architecture. That is, you would typically have a single 
 * method that manages retrival of all codes (not only this one), and 
 * the approach shown here is only used for learning purposes.
 * 
 * <p>
 * (C) 2000 Andersen Consulting
 * All Rights Reserved
 *<p>
 */

public class CustomerType 
{
	
	int typeId;
	String typeName;
	
	/**
	 * Allocates a CustomerType object with customer type id and
	 * customer type name provided as arguments.
	 */			
	public CustomerType(int id, String name) 
	{
		typeId = id;
		typeName = name;
	}
	
	/**
	 * @return the customer type ID
	 */								
	public int getTypeId() 
	{
		return typeId;
	}
	
	/**
	 * @return the customer type name
	 */								
	public String getTypeName() 
	{
		return typeName;
	}
	
	/**
	 * This method overrides the toString method of the super Object, 
	 * in order to provide a meaningfull string representation of 
	 * CustomerType objects. The string representation consists here 
	 * of the customer type name name.
	 * 
	 * @return the object string representation.
	 */								
	public String toString() 
	{
		return typeName;
	}
	
	
}
