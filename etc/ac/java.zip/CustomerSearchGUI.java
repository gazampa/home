import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.wfc.html.*;


/**
 * 
 * 
 * 
 * 
 */
public class CustomerSearchGUI extends Form
{
	
	private CustomerSearchCtrl controller;
	
	
	public CustomerSearchGUI(CustomerSearchCtrl ctrl)
	{
		super();

		// Required for Visual J++ Form Designer support
		initForm();		

		controller = ctrl;
	}

	/**
	 * CustomerSearchGUI overrides dispose so it can clean up the
	 * component list.
	 */
	public void dispose()
	{
		super.dispose();
		components.dispose();
	}

	private void select_click(Object source, Event e)
	{
		controller.select();
		
	}

	private void search_click(Object source, Event e)
	{
		controller.search();
	}
	
	

	private void cancel_click(Object source, Event e)
	{
		close();
	}

	private void customerList_click(Object source, Event e)
	{
		controller.determineFormState();
	}

	/**
	 * NOTE: The following code is required by the Visual J++ form
	 * designer.  It can be modified using the form editor.  Do not
	 * modify it using the code editor.
	 */
	Container components = new Container();
	Button select = new Button();
	Button search = new Button();
	GroupBox groupBox1 = new GroupBox();
	Label labelCustomerTypeID = new Label();
	ComboBox cbCustomerType = new ComboBox();
	Label label1 = new Label();
	Edit txtUserId = new Edit();
	Label labelFirstName = new Label();
	Edit txtFirstName = new Edit();
	Edit txtCorporateName = new Edit();
	Label labelCorporateName = new Label();
	Label labelLastName = new Label();
	Edit txtLastName = new Edit();
	Label labelEmailAdress = new Label();
	Edit txtEmail = new Edit();
	Button cancel = new Button();
	ListView customerList = new ListView();
	ColumnHeader lclID = new ColumnHeader();
	ColumnHeader lcName = new ColumnHeader();
	ColumnHeader lcCompany = new ColumnHeader();
	ColumnHeader lcEmail = new ColumnHeader();

	private void initForm()
	{
		this.setText("Customer Search");
		this.setAutoScaleBaseSize(new Point(5, 13));
		this.setClientSize(new Point(490, 455));
		this.setShowInTaskbar(false);

		select.setLocation(new Point(16, 416));
		select.setSize(new Point(75, 23));
		select.setTabIndex(9);
		select.setText("Select");
		select.addOnClick(new EventHandler(this.select_click));

		search.setLocation(new Point(96, 416));
		search.setSize(new Point(75, 23));
		search.setTabIndex(10);
		search.setText("Search");
		search.addOnClick(new EventHandler(this.search_click));

		groupBox1.setLocation(new Point(16, 8));
		groupBox1.setSize(new Point(448, 216));
		groupBox1.setTabIndex(4);
		groupBox1.setTabStop(false);
		groupBox1.setText("Search Criteria");

		labelCustomerTypeID.setBackColor(Color.CONTROL);
		labelCustomerTypeID.setLocation(new Point(24, 64));
		labelCustomerTypeID.setSize(new Point(80, 20));
		labelCustomerTypeID.setTabIndex(5);
		labelCustomerTypeID.setTabStop(false);
		labelCustomerTypeID.setText("Customer Type");

		cbCustomerType.setLocation(new Point(112, 64));
		cbCustomerType.setSize(new Point(176, 21));
		cbCustomerType.setTabIndex(1);
		cbCustomerType.setText("");
		cbCustomerType.setStyle(ComboBoxStyle.DROPDOWNLIST);

		label1.setLocation(new Point(24, 40));
		label1.setSize(new Point(64, 23));
		label1.setTabIndex(6);
		label1.setTabStop(false);
		label1.setText("User ID");

		txtUserId.setLocation(new Point(112, 40));
		txtUserId.setSize(new Point(176, 20));
		txtUserId.setTabIndex(0);
		txtUserId.setText("");

		labelFirstName.setBackColor(Color.CONTROL);
		labelFirstName.setLocation(new Point(24, 112));
		labelFirstName.setSize(new Point(72, 20));
		labelFirstName.setTabIndex(7);
		labelFirstName.setTabStop(false);
		labelFirstName.setText("FirstName");

		txtFirstName.setAnchor(ControlAnchor.TOPLEFTRIGHT);
		txtFirstName.setLocation(new Point(104, 112));
		txtFirstName.setSize(new Point(336, 20));
		txtFirstName.setTabIndex(2);
		txtFirstName.setText("");
		txtFirstName.setMaxLength(30);
		txtFirstName.setMultiline(true);

		txtCorporateName.setAnchor(ControlAnchor.TOPLEFTRIGHT);
		txtCorporateName.setLocation(new Point(88, 152));
		txtCorporateName.setSize(new Point(336, 20));
		txtCorporateName.setTabIndex(1);
		txtCorporateName.setText("");
		txtCorporateName.setMaxLength(50);
		txtCorporateName.setMultiline(true);

		labelCorporateName.setBackColor(Color.CONTROL);
		labelCorporateName.setLocation(new Point(8, 152));
		labelCorporateName.setSize(new Point(72, 20));
		labelCorporateName.setTabIndex(0);
		labelCorporateName.setTabStop(false);
		labelCorporateName.setText("Company");

		labelLastName.setBackColor(Color.CONTROL);
		labelLastName.setLocation(new Point(24, 136));
		labelLastName.setSize(new Point(56, 20));
		labelLastName.setTabIndex(8);
		labelLastName.setTabStop(false);
		labelLastName.setText("LastName");

		txtLastName.setAnchor(ControlAnchor.TOPLEFTRIGHT);
		txtLastName.setLocation(new Point(104, 136));
		txtLastName.setSize(new Point(336, 20));
		txtLastName.setTabIndex(3);
		txtLastName.setText("");
		txtLastName.setMaxLength(30);
		txtLastName.setMultiline(true);

		labelEmailAdress.setBackColor(Color.CONTROL);
		labelEmailAdress.setLocation(new Point(8, 176));
		labelEmailAdress.setSize(new Point(48, 20));
		labelEmailAdress.setTabIndex(3);
		labelEmailAdress.setTabStop(false);
		labelEmailAdress.setText("Email");

		txtEmail.setAnchor(ControlAnchor.TOPLEFTRIGHT);
		txtEmail.setLocation(new Point(88, 176));
		txtEmail.setSize(new Point(336, 20));
		txtEmail.setTabIndex(2);
		txtEmail.setText("");
		txtEmail.setMaxLength(40);
		txtEmail.setMultiline(true);

		cancel.setLocation(new Point(176, 416));
		cancel.setSize(new Point(75, 23));
		cancel.setTabIndex(11);
		cancel.setText("Cancel");
		cancel.addOnClick(new EventHandler(this.cancel_click));

		lclID.setText("ID");

		lcName.setText("Name");
		lcName.setWidth(131);

		lcCompany.setText("Company");
		lcCompany.setWidth(129);

		lcEmail.setText("Email");
		lcEmail.setWidth(124);

		customerList.setLocation(new Point(16, 240));
		customerList.setSize(new Point(448, 160));
		customerList.setTabIndex(12);
		customerList.setText("listView1");
		customerList.setFullRowSelect(true);
		customerList.setHeaderStyle(ColumnHeaderStyle.NONCLICKABLE);
		customerList.setMultiSelect(false);
		customerList.setView(ViewEnum.REPORT);
		customerList.setColumns(new ColumnHeader[] {
								lclID, 
								lcName, 
								lcCompany, 
								lcEmail});
		customerList.addOnClick(new EventHandler(this.customerList_click));

		this.setNewControls(new Control[] {
							customerList, 
							cancel, 
							txtLastName, 
							labelLastName, 
							txtFirstName, 
							labelFirstName, 
							txtUserId, 
							label1, 
							cbCustomerType, 
							labelCustomerTypeID, 
							groupBox1, 
							search, 
							select});
		groupBox1.setNewControls(new Control[] {
								 txtEmail, 
								 labelEmailAdress, 
								 txtCorporateName, 
								 labelCorporateName});
	}

}
