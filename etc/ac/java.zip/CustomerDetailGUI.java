//Customer_Detail2.java

import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.wfc.data.*;
import com.ms.wfc.data.ui.*;

public class CustomerDetailGUI extends Form
{
	private CustomerDetailCtrl controller;

    public void dispose()
    {
        super.dispose();
        components.dispose();
    }
	
    public CustomerDetailGUI(CustomerDetailCtrl ctrl)
    {
        // Required for Visual J++ Form Designer support
        initForm();

		controller = ctrl;
		addOnClosing(new CancelEventHandler(formClose));
		
        this.update();		        
		
    }
	
	private void formClose(Object source, CancelEvent e) {
		controller.exit(e);
	}
		
	private void newCustomer_click(Object source, Event e) 
	{
		controller.newCustomer();
	}

	private void open_click(Object source, Event e) 
	{
		controller.openCustomer();
	}
	
	private void exit_click(Object source, Event e)
	{
		controller.exit();
	}

	private void saveCustomer_click(Object source, Event e)
	{		
		controller.save();
	}

	private void txtUserName_textChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}	
	
	private void cbCustomerType_selectedIndexChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}

	private void txtFirstName_textChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}

	private void txtMiddleInitial_textChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}

	private void txtLastName_textChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}

	private void txtCompany_textChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}

	private void txtAddress1_textChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}

	private void txtAddress2_textChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}

	private void txtCity_textChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}

	private void cbStateList_selectedIndexChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}

	private void txtZIP_textChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}

	private void txtEmail_textChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}

	private void txtPhone_textChanged(Object source, Event e)
	{
		controller.markAsDirty();
	}



	private void resetPassword_click(Object source, Event e)
	{
		controller.resetPassword();
	}



	/**
	 * NOTE: The following code is required by the Visual J++ form
	 * designer.  It can be modified using the form editor.  Do not
	 * modify it using the code editor.
	 */
	Container components = new Container();
	GroupBox groupBox3 = new GroupBox();
	Label labelCorporateName = new Label();
	Edit txtCompany = new Edit();
	Label labelAddress1 = new Label();
	Edit txtAddress1 = new Edit();
	Label labelAddress2 = new Label();
	Edit txtAddress2 = new Edit();
	Label labelCity = new Label();
	Label labelCustomerID = new Label();
	Edit txtCustId = new Edit();
	Label labelCustomerTypeID = new Label();
	ComboBox cbCustomerType = new ComboBox();
	Edit txtCity = new Edit();
	Label labelState = new Label();
	Label labelFirstName = new Label();
	Edit txtFirstName = new Edit();
	Label labelLastName = new Label();
	Edit txtLastName = new Edit();
	Label labelMiddleInitial = new Label();
	Label label1 = new Label();
	GroupBox groupBox1 = new GroupBox();
	ComboBox cbStateList = new ComboBox();
	Label labelZIP = new Label();
	Edit txtZIP = new Edit();
	Label labelEmailAdress = new Label();
	Edit txtMiddleInitial = new Edit();
	Edit txtUserName = new Edit();
	Edit txtEmail = new Edit();
	Label labelPhone = new Label();
	GroupBox groupBox2 = new GroupBox();
	Edit txtPhone = new Edit();
	MainMenu custMenu = new MainMenu();
	MenuItem menuItem1 = new MenuItem();
	MenuItem newCustomer = new MenuItem();
	MenuItem openCustomer = new MenuItem();
	MenuItem menuItem2 = new MenuItem();
	MenuItem saveCustomer = new MenuItem();
	MenuItem menuItem4 = new MenuItem();
	MenuItem exit = new MenuItem();
	MenuItem menuItem3 = new MenuItem();
	MenuItem resetPassword = new MenuItem();
	PictureBox pictureBox1 = new PictureBox();

	private void initForm()
	{
		// NOTE:  This form is storing resource information in an
		// external file.  Do not modify the string parameter to any
		// resources.getObject() function call. For example, do not
		// modify "foo1_location" in the following line of code
		// even if the name of the Foo object changes: 
		//   foo1.setLocation((Point)resources.getObject("foo1_location"));

		IResourceManager resources = new ResourceManager(this, "CustomerDetailGUI");
		groupBox3.setLocation(new Point(8, 248));
		groupBox3.setSize(new Point(464, 240));
		groupBox3.setTabIndex(12);
		groupBox3.setTabStop(false);
		groupBox3.setText("Address");

		labelCorporateName.setBackColor(Color.CONTROL);
		labelCorporateName.setLocation(new Point(24, 280));
		labelCorporateName.setSize(new Point(72, 20));
		labelCorporateName.setTabIndex(26);
		labelCorporateName.setTabStop(false);
		labelCorporateName.setText("Company");

		txtCompany.setLocation(new Point(104, 280));
		txtCompany.setSize(new Point(281, 20));
		txtCompany.setTabIndex(8);
		txtCompany.setText("");
		txtCompany.setMaxLength(50);
		txtCompany.setMultiline(true);
		txtCompany.addOnTextChanged(new EventHandler(this.txtCompany_textChanged));

		labelAddress1.setBackColor(Color.CONTROL);
		labelAddress1.setLocation(new Point(24, 304));
		labelAddress1.setSize(new Point(64, 20));
		labelAddress1.setTabIndex(0);
		labelAddress1.setTabStop(false);
		labelAddress1.setText("Address1");

		txtAddress1.setLocation(new Point(104, 304));
		txtAddress1.setSize(new Point(281, 20));
		txtAddress1.setTabIndex(9);
		txtAddress1.setText("");
		txtAddress1.setMaxLength(50);
		txtAddress1.setMultiline(true);
		txtAddress1.addOnTextChanged(new EventHandler(this.txtAddress1_textChanged));

		labelAddress2.setBackColor(Color.CONTROL);
		labelAddress2.setLocation(new Point(24, 328));
		labelAddress2.setSize(new Point(56, 20));
		labelAddress2.setTabIndex(13);
		labelAddress2.setTabStop(false);
		labelAddress2.setText("Address2");

		txtAddress2.setLocation(new Point(104, 328));
		txtAddress2.setSize(new Point(281, 20));
		txtAddress2.setTabIndex(10);
		txtAddress2.setText("");
		txtAddress2.setMaxLength(50);
		txtAddress2.setMultiline(true);
		txtAddress2.addOnTextChanged(new EventHandler(this.txtAddress2_textChanged));

		labelCity.setBackColor(Color.CONTROL);
		labelCity.setLocation(new Point(24, 352));
		labelCity.setSize(new Point(40, 20));
		labelCity.setTabIndex(17);
		labelCity.setTabStop(false);
		labelCity.setText("City");

		labelCustomerID.setBackColor(Color.CONTROL);
		labelCustomerID.setLocation(new Point(16, 32));
		labelCustomerID.setSize(new Point(72, 20));
		labelCustomerID.setTabIndex(18);
		labelCustomerID.setTabStop(false);
		labelCustomerID.setText("Customer No.");

		txtCustId.setBackColor(Color.MENU);
		txtCustId.setLocation(new Point(96, 24));
		txtCustId.setSize(new Point(112, 20));
		txtCustId.setTabIndex(0);
		txtCustId.setText("");
		txtCustId.setReadOnly(true);

		labelCustomerTypeID.setBackColor(Color.CONTROL);
		labelCustomerTypeID.setLocation(new Point(16, 80));
		labelCustomerTypeID.setSize(new Point(80, 20));
		labelCustomerTypeID.setTabIndex(22);
		labelCustomerTypeID.setTabStop(false);
		labelCustomerTypeID.setText("Customer Type");

		cbCustomerType.setLocation(new Point(104, 80));
		cbCustomerType.setSize(new Point(112, 21));
		cbCustomerType.setTabIndex(4);
		cbCustomerType.setText("");
		cbCustomerType.setStyle(ComboBoxStyle.DROPDOWNLIST);
		cbCustomerType.addOnSelectedIndexChanged(new EventHandler(this.cbCustomerType_selectedIndexChanged));

		txtCity.setLocation(new Point(104, 352));
		txtCity.setSize(new Point(281, 20));
		txtCity.setTabIndex(11);
		txtCity.setText("");
		txtCity.setMaxLength(40);
		txtCity.setMultiline(true);
		txtCity.addOnTextChanged(new EventHandler(this.txtCity_textChanged));

		labelState.setBackColor(Color.CONTROL);
		labelState.setLocation(new Point(24, 376));
		labelState.setSize(new Point(40, 20));
		labelState.setTabIndex(19);
		labelState.setTabStop(false);
		labelState.setText("State");

		labelFirstName.setBackColor(Color.CONTROL);
		labelFirstName.setLocation(new Point(16, 152));
		labelFirstName.setSize(new Point(72, 20));
		labelFirstName.setTabIndex(24);
		labelFirstName.setTabStop(false);
		labelFirstName.setText("FirstName");

		txtFirstName.setLocation(new Point(104, 152));
		txtFirstName.setSize(new Point(280, 20));
		txtFirstName.setTabIndex(5);
		txtFirstName.setText("");
		txtFirstName.setMaxLength(30);
		txtFirstName.setMultiline(true);
		txtFirstName.addOnTextChanged(new EventHandler(this.txtFirstName_textChanged));

		labelLastName.setBackColor(Color.CONTROL);
		labelLastName.setLocation(new Point(16, 200));
		labelLastName.setSize(new Point(56, 20));
		labelLastName.setTabIndex(25);
		labelLastName.setTabStop(false);
		labelLastName.setText("LastName");

		txtLastName.setLocation(new Point(104, 200));
		txtLastName.setSize(new Point(280, 20));
		txtLastName.setTabIndex(7);
		txtLastName.setText("");
		txtLastName.setMaxLength(30);
		txtLastName.setMultiline(true);
		txtLastName.addOnTextChanged(new EventHandler(this.txtLastName_textChanged));

		labelMiddleInitial.setBackColor(Color.CONTROL);
		labelMiddleInitial.setLocation(new Point(16, 176));
		labelMiddleInitial.setSize(new Point(56, 20));
		labelMiddleInitial.setTabIndex(27);
		labelMiddleInitial.setTabStop(false);
		labelMiddleInitial.setText("MiddleInitial");

		label1.setLocation(new Point(16, 56));
		label1.setSize(new Point(64, 23));
		label1.setTabIndex(28);
		label1.setTabStop(false);
		label1.setText("User Name");

		groupBox1.setLocation(new Point(8, 8));
		groupBox1.setSize(new Point(288, 104));
		groupBox1.setTabIndex(1);
		groupBox1.setTabStop(false);
		groupBox1.setText("General Information");

		cbStateList.setLocation(new Point(96, 128));
		cbStateList.setSize(new Point(121, 21));
		cbStateList.setTabIndex(0);
		cbStateList.setText("");
		cbStateList.setStyle(ComboBoxStyle.DROPDOWNLIST);
		cbStateList.addOnSelectedIndexChanged(new EventHandler(this.cbStateList_selectedIndexChanged));

		labelZIP.setBackColor(Color.CONTROL);
		labelZIP.setLocation(new Point(24, 400));
		labelZIP.setSize(new Point(32, 20));
		labelZIP.setTabIndex(20);
		labelZIP.setTabStop(false);
		labelZIP.setText("ZIP");

		txtZIP.setLocation(new Point(104, 400));
		txtZIP.setSize(new Point(281, 20));
		txtZIP.setTabIndex(14);
		txtZIP.setText("");
		txtZIP.setMaxLength(9);
		txtZIP.setMultiline(true);
		txtZIP.addOnTextChanged(new EventHandler(this.txtZIP_textChanged));

		labelEmailAdress.setBackColor(Color.CONTROL);
		labelEmailAdress.setLocation(new Point(24, 424));
		labelEmailAdress.setSize(new Point(48, 20));
		labelEmailAdress.setTabIndex(21);
		labelEmailAdress.setTabStop(false);
		labelEmailAdress.setText("Email");

		txtMiddleInitial.setLocation(new Point(104, 176));
		txtMiddleInitial.setSize(new Point(40, 20));
		txtMiddleInitial.setTabIndex(6);
		txtMiddleInitial.setText("");
		txtMiddleInitial.setMaxLength(1);
		txtMiddleInitial.addOnTextChanged(new EventHandler(this.txtMiddleInitial_textChanged));

		txtUserName.setLocation(new Point(104, 56));
		txtUserName.setSize(new Point(112, 20));
		txtUserName.setTabIndex(3);
		txtUserName.setText("");
		txtUserName.setMaxLength(8);
		txtUserName.addOnTextChanged(new EventHandler(this.txtUserName_textChanged));

		txtEmail.setLocation(new Point(104, 424));
		txtEmail.setSize(new Point(281, 20));
		txtEmail.setTabIndex(15);
		txtEmail.setText("");
		txtEmail.setMaxLength(40);
		txtEmail.setMultiline(true);
		txtEmail.addOnTextChanged(new EventHandler(this.txtEmail_textChanged));

		labelPhone.setBackColor(Color.CONTROL);
		labelPhone.setLocation(new Point(24, 448));
		labelPhone.setSize(new Point(40, 20));
		labelPhone.setTabIndex(23);
		labelPhone.setTabStop(false);
		labelPhone.setText("Phone");

		groupBox2.setLocation(new Point(8, 128));
		groupBox2.setSize(new Point(464, 104));
		groupBox2.setTabIndex(2);
		groupBox2.setTabStop(false);
		groupBox2.setText("Name");

		txtPhone.setLocation(new Point(104, 448));
		txtPhone.setSize(new Point(281, 20));
		txtPhone.setTabIndex(16);
		txtPhone.setText("");
		txtPhone.setMaxLength(10);
		txtPhone.setMultiline(true);
		txtPhone.addOnTextChanged(new EventHandler(this.txtPhone_textChanged));

		newCustomer.setShortcut(Shortcut.CTRL_N);
		newCustomer.setText("New...");
		newCustomer.addOnClick(new EventHandler(this.newCustomer_click));

		openCustomer.setShortcut(Shortcut.CTRL_O);
		openCustomer.setText("Open...");
		openCustomer.addOnClick(new EventHandler(this.open_click));

		menuItem2.setText("-");

		saveCustomer.setShortcut(Shortcut.CTRL_S);
		saveCustomer.setText("&Save");
		saveCustomer.addOnClick(new EventHandler(this.saveCustomer_click));

		menuItem4.setText("-");

		exit.setText("&Exit");
		exit.addOnClick(new EventHandler(this.exit_click));

		menuItem1.setMenuItems(new MenuItem[] {
							   newCustomer, 
							   openCustomer, 
							   menuItem2, 
							   saveCustomer, 
							   menuItem4, 
							   exit});
		menuItem1.setText("Customer");

		resetPassword.setText("Reset Password");
		resetPassword.addOnClick(new EventHandler(this.resetPassword_click));

		menuItem3.setMenuItems(new MenuItem[] {
							   resetPassword});
		menuItem3.setText("Utilities");

		custMenu.setMenuItems(new MenuItem[] {
							  menuItem1, 
							  menuItem3});
		/* @designTimeOnly custMenu.setLocation(new Point(408, 0)); */

		this.setLocation(new Point(7, 7));
		this.setText("Customer");
		this.setAutoScaleBaseSize(new Point(5, 13));
		this.setAutoScroll(true);
		this.setClientSize(new Point(500, 514));
		this.setMenu(custMenu);
		this.setStartPosition(FormStartPosition.CENTER_SCREEN);

		pictureBox1.setLocation(new Point(336, 32));
		pictureBox1.setSize(new Point(112, 64));
		pictureBox1.setTabIndex(29);
		pictureBox1.setTabStop(false);
		pictureBox1.setText("pictureBox1");
		pictureBox1.setImage((Bitmap)resources.getObject("pictureBox1_image"));

		this.setNewControls(new Control[] {
							pictureBox1, 
							txtPhone, 
							labelPhone, 
							txtEmail, 
							labelEmailAdress, 
							txtZIP, 
							labelZIP, 
							labelState, 
							txtCity, 
							labelCity, 
							txtAddress2, 
							labelAddress2, 
							txtAddress1, 
							labelAddress1, 
							txtCompany, 
							labelCorporateName, 
							groupBox3, 
							txtUserName, 
							label1, 
							cbCustomerType, 
							txtMiddleInitial, 
							labelCustomerID, 
							labelCustomerTypeID, 
							labelFirstName, 
							txtFirstName, 
							labelLastName, 
							txtLastName, 
							labelMiddleInitial, 
							groupBox1, 
							groupBox2});
		groupBox3.setNewControls(new Control[] {
								 cbStateList});
		groupBox1.setNewControls(new Control[] {
								 txtCustId});
	}
    //NOTE: End of form designer support code.

}
